

Try to throw your opponents out in this intensely adrenalitic deathmatch game.

Perfect for a quick match with your friends, and fun for all family.


Input:
	Player 1:
		Movement: Arrow keys
		Dash: Key 0

	Player 2:
		Movement: WASD
		Dash: Left shift/ctrl
		Can also use controller 2

	Player 3:
		Movement: UHJK
		Dash: Right shift/ctrl
		Can also use controller 1



Team:
	Undi (Pablo de la Ossa, http://autumnyard.com)
	Nico Gil Soriano
	Cartorm3